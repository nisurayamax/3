#!/bin/sh
./skypool-nimiq-v1.3.4-linux-x64/skypool-node-client --address="NQ21 0SNK H4BU EE20 UCU7 0RE7 7TYK BT4R X7S9" --thread=2 --name="pepek"
